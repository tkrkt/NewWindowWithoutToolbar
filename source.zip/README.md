How to build

```
$ npm install
$ npm run dist
```

then exntension package is created in `dist` directory.

Source code is in src/scripts